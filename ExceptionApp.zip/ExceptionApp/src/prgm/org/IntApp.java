package prgm.org;

import java.util.Scanner;

interface stringoperation
{
	public void setstring(String str);
	public void performoperation();
}
class countspace implements stringoperation
{
	String s;
	public void setstring(String str)
	{
		s=str;
	}
	public void performoperation()
	{
		int spaces=0;
		char ch[]=s.toCharArray();
		for(int i=0;i<s.length();i++)
		{
			if(ch[i]==' ')
			{
				spaces++;
			}
		}
		System.out.println("Spaces are "+spaces);
		System.out.println("-----------------------");
	}
	
}
class MajorityString implements stringoperation
{
	String s;
	public void setstring(String str)
	{
		this.s=str;
	}
	public void performoperation()
	{
        int count=0;
		
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			count=0;
			for(int j=0;j<s.length();j++)
			{
				char c=s.charAt(j);
				if(j<i && ch==c)
				{
					break;
				}
				if(ch==' ')
				{
					break;
				}
				if(ch==c)
				{
					count++;
				}
			}
			if(count>0 && count>(s.length()/2))
			{
				System.out.println(ch+" is magority character repeated "+count+" times");
			}
		
	}
}
class OccuranceString implements stringoperation
{
	String s;
	public void setstring(String str)
	{
		s=str;
	}
	public void performoperation()
	{
		int count=0;
		
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			count=0;
			for(int j=0;j<s.length();j++)
			{
				char c=s.charAt(j);
				if(j<i && ch==c)
				{
					break;
				}
				if(ch==' ')
				{
					break;
				}
				if(ch==c)
				{
					count++;
				}
			}
			if(count>0)
			{
				System.out.println(ch+" repeated "+count+" times");
			}
		
		}
	}
}
public  class IntApp {

	public static void main(String[] args) {
		
		  Scanner xyz=new Scanner(System.in);
	        String str;
	        System.out.println("Enter string");
	        str=xyz.next();
	        stringoperation so=new countspace();
	        so.setstring(str); 
	        so.performoperation();
	        so=new MajorityString();
	        so.setstring(str);
	        so.performoperation();
	        so=new OccuranceString();
	        so.setstring(str);
	        so.performoperation();
		}
	}

}

