package prgm.org;

public class Excp4App {
	 static String s="good";
	public static void main(String[] args) {
		try {
			 char ch=s.charAt(5);
			 System.out.println(ch);
		   }
		catch(StringIndexOutOfBoundsException ex) 
		{
			   System.out.println("Error is "+ex);
		   }

	}

}
