package prgm.org;

public class Exc3App {

	public static void main(String[] args) {
		try {	
			String s = "1234 ";
			int a = Integer.parseInt(s);
			System.out.printf("A = %d\n", a);
		 }
		 catch(NumberFormatException ex) {
			 System.out.println("Error is "+ex);
		 }

	}

}
