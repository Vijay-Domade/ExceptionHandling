package prgm.org;
import java.util.*;
class voterException extends ArithmeticException
{
	public String getvoterError()
	{
		return "You cannot vote";
	}
}
class Voter 
{
	void VerifyAge(int age)
	{
		if(age<18)
		{
			voterException ve=new voterException();
			throw ve;
		}
		else
		{
			System.out.println("You can vote");
		}
	}
}
public class votingApp {

	public static void main(String[] args) {
		try {
	Voter v=new Voter();
	v.VerifyAge(16); 
	       }
	catch(voterException ex)	
		{
		 System.out.println(ex.getvoterError());
		}
	}

}
