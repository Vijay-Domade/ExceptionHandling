package prgm.org;

public class ExcpApp {

	public static void main(String[] args) {
		int a[]=new int[] {10,20,30};
			try
			{
			   System.out.println(a[3]);
			}
			catch(ArrayIndexOutOfBoundsException ex)
			{
				System.out.println("Error is "+ex);
			}

	}

}
