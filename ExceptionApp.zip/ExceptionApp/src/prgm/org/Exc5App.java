package prgm.org;




import java.util.*;

public class Exc5App {

	public static void main(String[] args) {
		  int a;
		  int b;
		    Scanner xyz  = new Scanner(System.in);
		   try {
		    System.out.println("Enter two values");
		    a=xyz.nextInt();
		    b=xyz.nextInt();
		    System.out.println("Addition is "+(a+b));
		   }
		   catch(InputMismatchException ex)
		   {
			   System.out.println("Error is "+ex);
			   
		   }

	}

}
