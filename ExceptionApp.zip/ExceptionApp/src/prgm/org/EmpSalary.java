package prgm.org;

import java.util.Scanner;

interface Employee
{
	public void setEmployee(int ID,String name,int Salary);
	
}
class ITEmployee implements Employee
{
	int ID,Salary;
	String name;
	public void setEmployee(int ID,String name,int Salary)
	{
		this.ID=ID;
		this.name=name;
		this.Salary=Salary;
		
	}
	void validateEmp()
	{
		System.out.println("before increment salary="+Salary);
		 if(Salary>10000)
		 {
			 
			 Salary=(int) (Salary+0.10*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else if(Salary>30000)
		 {
			 Salary=(int) (Salary+0.12*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else if(Salary<10000)
		 {
			 Salary=(int) (Salary+0.15*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else
		 {
			 System.out.println("No salary increment");
		 }
	}
}
class MgmtEmployee implements Employee
{
	int ID,Salary;
	String name;
	 public void setEmployee(int ID,String name,int Salary)
	 {
		 this.ID=ID;
		 this.name=name;
		 this.Salary=Salary;
	 }
	 void validateEmp()
		{
		 System.out.println("before increment salary="+Salary);
		 if(Salary>10000)
		 {
			 
			 Salary=(int) (Salary+0.10*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else if(Salary>30000)
		 {
			 Salary=(int) (Salary+0.12*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else if(Salary<10000)
		 {
			 Salary=(int) (Salary+0.15*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else
		 {
			 System.out.println("No salary increment");
		 }
			
		}
}
class GovtEmployee implements Employee
{
	int ID,Salary;
	String name;
	 public void setEmployee(int ID,String name,int Salary)
	 {
		this.ID=ID;
		this.name=name;
		this.Salary=Salary;
	 }
	 void validateEmp()
		{
		 System.out.println("before increment salary="+Salary);
		 if(Salary>10000)
		 {
			 
			 Salary=(int) (Salary+0.10*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else if(Salary>30000)
		 {
			 Salary=(int) (Salary+0.12*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else if(Salary<10000)
		 {
			 Salary=(int) (Salary+0.15*Salary);
			 System.out.println("Incremented salary="+Salary);
		 }
		 else
		 {
			 System.out.println("No salary increment");
		 }
		}
}
public class EmpSalary {

	public static void main(String[] args) {
		Scanner xyz=new Scanner(System.in);
		int id,sal;
		String name;
		
		System.out.println("Enter IT employee details such as ID,name,Salary");
		id=xyz.nextInt();
		name=xyz.next();
		sal=xyz.nextInt();
		ITEmployee ie=new ITEmployee();
		ie.setEmployee(id, name, sal);
		ie.validateEmp();
		
		System.out.println("Enter Management employee details such as ID,name,Salary");
		id=xyz.nextInt();
		name=xyz.next();
		sal=xyz.nextInt();
		MgmtEmployee mg=new MgmtEmployee();
		mg.setEmployee(id, name, sal);
		mg.validateEmp();
		
		System.out.println("Enter Government employee details such as ID,name,Salary");
		id=xyz.nextInt();
		name=xyz.next();
		sal=xyz.nextInt();
		GovtEmployee g=new GovtEmployee();
		g.setEmployee(id, name, sal);
		g.validateEmp();
		
		
		

	}

}
